<!DOCTYPE html>
    <body>
        <script type="text/javascript">
            var book="maths";
            if(book=="history")
        {document.write("<b> history book</b>");

        }
        elseif( book=="maths")
        {document.write("<b> maths books</b>");
        }
        else(book="geo")
        {document.write("<b>geo</b>");}
</script>
    </body>
    </html>